拾账 Android APK 项目源码（尚未编译成 APK）

本项目将拾账网页直接嵌入 Android WebView，主要功能可离线运行，账目保存在应用 WebView 的本地存储中。

重要：
- 这是 Android Studio 项目源码，不是可直接安装的 APK。
- 本项目需要 Android SDK / Android Studio 或支持 Android Gradle 构建的云端构建环境才能编译。
- 当前交付环境未提供 Android SDK/Gradle 构建链，因此不能在这里声称已经生成 APK。
- 账目仅存储在应用本地。卸载应用、清除应用数据可能导致账目丢失，请定期使用软件内的“导出完整备份”。
- 首次打开软件后可在设置里导出 JSON 备份，导入备份功能可恢复数据。
- Android 系统的文件下载/文件选择权限因 WebView 实现而异；如导入导出按钮在某些设备上不能直接调用系统文件选择器，需进一步增加 Android 原生文件选择桥接功能。
